
  # Data Science Portfolio

  This is a code bundle for Data Science Portfolio. The original project is available at https://www.figma.com/design/xHdLSRvaofP0Xfa5MF5xX9/Data-Science-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  